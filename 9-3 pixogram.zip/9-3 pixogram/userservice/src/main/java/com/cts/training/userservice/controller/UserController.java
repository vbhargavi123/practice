package com.cts.training.userservice.controller;

import java.util.List;
import java.util.Optional;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cts.training.userservice.entity.User;
import com.cts.training.userservice.exception.UserErrorResponse;
import com.cts.training.userservice.exception.UserNotFoundException;
import com.cts.training.userservice.model.DataModel;
import com.cts.training.userservice.model.UserOutput;
import com.cts.training.userservice.repository.UserRepository;
import com.cts.training.userservice.service.IUserService;
import com.cts.training.userservice.service.RolesService;


@RestController
public class UserController {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	// dependency
	@Autowired
	private IUserService userService;
	 
	@Autowired
	private RolesService roleService;
	
	
	// REST method that will recieve a movie Id and return details of that movie
	 

	@GetMapping("/users")
	public ResponseEntity<DataModel> getall(){
		DataModel data = new DataModel();
		data.setUsers(this.userService.findAllUsers());
		ResponseEntity<DataModel> result = new ResponseEntity<DataModel>(data, HttpStatus.OK);
		return result;
	}
	
	@GetMapping("/users/{userId}")
	public ResponseEntity<UserOutput> getById(@PathVariable Integer userId){
		UserOutput user = new UserOutput();
		User record = new User();
		Optional<User> users = this.userService.findUserById(userId);
		if(users.isPresent())
			record = users.get();
		else {
			throw new UserNotFoundException("User not found");
		}
		user.setId(record.getId());
		user.setUsername(record.getUsername());
	user.setPassword(record.getPassword());
		user.setEmail(record.getEmail());
		user.setProfile(record.getProfile());
		ResponseEntity<UserOutput> result = new ResponseEntity<UserOutput>(user, HttpStatus.OK);
		return result;
	}
}
	
	//save new user
	/*@PostMapping("/users")
	public boolean save(@RequestBody UserOutput user) {
		public ResponseEntity<User> save(@RequestParam("file") MultipartFile file,
				@RequestParam("id") long id, @RequestParam("username") String username, @RequestParam("password") String password,
				@RequestParam("email") String email, @RequestParam("profile") String profile) {
			
			// explicitly need to create product object
			User user = new User(id,username, password,email,profile );
					
			if(!this.userService.addUser(user))
				throw new RuntimeException("Could not add new record!!!");
			
			// string file in static folder
			this.storageservice.store(file);
			
			logger.info("Media is uploaded successfully " + file.getOriginalFilename() + "!");
			
			
			ResponseEntity<User> response = 
					new ResponseEntity<User>(user, HttpStatus.OK);


		
		
		// this.userServices.saveuser(user);
		return response;
		
	}*/
	
	/*//update user
	@PutMapping("/users")
	public boolean update(@RequestBody UserOutput user) {
		
		public ResponseEntity<User> saveUpdate(@RequestBody User user) {
			if(!this.userService.updateUser(user))
				throw new RuntimeException("Could not update record!!!");
			ResponseEntity<User> response = 
					new ResponseEntity<User>(user, HttpStatus.OK);

		
		this.userService.updateUser(user);
		return response;
		
	}
	
	@ExceptionHandler  // ~catch
	public ResponseEntity<UserErrorResponse> productOperationErrorHAndler(Exception ex) {
		// create error object
		UserErrorResponse error = new UserErrorResponse(ex.getMessage(), 
															  HttpStatus.BAD_REQUEST.value(), 
															  System.currentTimeMillis());
		ResponseEntity<UserErrorResponse> response =
										new ResponseEntity<UserErrorResponse>(error, HttpStatus.NOT_FOUND);
		logger.error("Exception :" + error);
		
		return response;
	}

	
	@ExceptionHandler  // ~catch
	public ResponseEntity<UserErrorResponse> UserOperationErrorHAndler(Exception ex) {
		// create error object
		UserErrorResponse error = new UserErrorResponse(ex.getMessage(), 
															  HttpStatus.BAD_REQUEST.value(), 
															  System.currentTimeMillis());
		ResponseEntity<UserErrorResponse> response =
										new ResponseEntity<UserErrorResponse>(error, HttpStatus.NOT_FOUND);
		logger.error("Exception :" + error);
		
		return response;
	}*/
	
	
	
	/************ REST endpoints ************/
	// /api/User [GET]
	// /api/User/id [GET]
	// /api/User [POST]
	// /api/User [PUT]
	// /api/User/id [DELETE]
	
	
	
	

	





















