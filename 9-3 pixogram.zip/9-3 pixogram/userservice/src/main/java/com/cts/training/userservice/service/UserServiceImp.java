package com.cts.training.userservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cts.training.userservice.entity.Roles;
import com.cts.training.userservice.entity.User;
import com.cts.training.userservice.model.UserInput;
import com.cts.training.userservice.model.UserOutput;
import com.cts.training.userservice.repository.RolesRepository;
import com.cts.training.userservice.repository.UserRepository;
@Component
public class UserServiceImp implements IUserService {
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private RolesRepository roleRepository;

	public List<User>findAllUsers(){
		List<User> records=this.userRepository.findAll();
		return records;
		
	}
	public Optional<User>findUserById (Integer id){
		Optional<User> record= this.userRepository.findById(id);
		return record;
		
	}
	
	public void addUser(UserInput user) {
		User data = new User();
		//Authorities auth = new Authorities();
		//auth.setUsername(user.getUsername());
		//auth.setAuthority("ROLE_USER");
		// data.setId(user.getId());
		data.setUsername(user.getUsername());
		data.setPassword(user.getPassword());
	
		data.setEmail(user.getEmail());
		data.setProfile(user.getProfile());
		
		data.setPassword("{noop}" + user.getPassword());
		
		data.setEnabled(true);
		this.userRepository.save(data);
		
		// add authority
		Roles role = new Roles(user.getUsername(), "ROLE_USER");
		this.roleRepository.save(role);
	}
	
	public void updateUser(UserOutput user) {
		User data = new User();
		//Authorities auth = new Authorities();
		//auth.setUsername(user.getUsername());
		//auth.setAuthority("ROLE_USER");
		data.setId(user.getId());
		data.setUsername(user.getUsername());
		
		data.setEmail(user.getEmail());
		
		data.setPassword(user.getPassword());
		data.setProfile(user.getProfile());
		data.setEnabled(true);
		this.userRepository.save(data);
	}
	
	}

