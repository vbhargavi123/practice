// import { Component, OnInit } from '@angular/core';
// import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
// import { SearchedUserModel } from '../model/SearchedUserModel.model';
// import { UserAuthService } from '../services/user-auth.service';
// import { UserserviceService } from '../services/DataServices/userservice.service';
// import { SearchedUserModelList } from '../model/SearchedUserModelList.model';

// @Component({
//   selector: 'app-search',
//   templateUrl: './search.component.html',
//   styleUrls: ['./search.component.css']
// })
// export class SearchComponent implements OnInit {

//   searchText:string;
//   myFormGroup: FormGroup;
//   userList : Array<SearchedUserModel>;
//   constructor(formBuilder: FormBuilder,public userserviceService:UserserviceService) {
//     this.myFormGroup = formBuilder.group({
//       "searchText": new FormControl("")
//     });
//    }
//    search():void
//    {
//      this.searchText=this.myFormGroup.get('searchText').value;
//      this.userserviceService.getSearchResult(this.searchText).subscribe(
//        (response : SearchedUserModelList) => {
//          this.userList = response.userList;
//          this.userList = this.userList.map(user =>{
//            user.profileUrl = "http://localhost:8765/user-service/"+user.profileUrl;
//            return user;
//          });
         
//        }
//      );
//    }

//   ngOnInit() {
//   }

// }
