import { Component, OnInit } from '@angular/core';
import { UserserviceService } from 'src/app/services/DataServices/userservice.service';
import { RetrieveMedia } from 'src/app/model/RetrieveMedia.model';
import { UserAuthService } from 'src/app/services/user-auth.service';

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css']
})
export class GalleryComponent implements OnInit {

  mymedia:Array<RetrieveMedia>
  constructor(public userserviceService:UserserviceService,public auth:UserAuthService) { }
  userId:string;
  
  ngOnInit() {
    this.userId=this.auth.getUserId();
    this.userserviceService.getAllMedia(this.userId).subscribe(data=>{
      this.mymedia=data;
      for(let media of this.mymedia)
      {
        media.url="http://localhost:8765/media-service/"+media.url;
      }
    });
  }

}
