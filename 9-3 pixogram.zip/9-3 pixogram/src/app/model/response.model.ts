export class Response{
    message : String;
    timestamp : number;
    userId : number;
    profile:string;
}