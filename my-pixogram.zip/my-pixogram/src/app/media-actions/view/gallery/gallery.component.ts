import { Component, OnInit } from '@angular/core';
import { UserserviceService } from 'src/app/services/DataServices/userservice.service';
import { RetrieveMedia } from 'src/app/model/RetrieveMedia.model';

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css']
})
export class GalleryComponent implements OnInit {

  mymedia:Array<RetrieveMedia>
  constructor(public userserviceService:UserserviceService) { }

  ngOnInit() {
    this.userserviceService.getAllMedia().subscribe(data=>{
      this.mymedia=data;
      for(let media of this.mymedia)
      {
        media.url="http://localhost:8765/media-service/"+media.url;
      }
    });
  }

}
