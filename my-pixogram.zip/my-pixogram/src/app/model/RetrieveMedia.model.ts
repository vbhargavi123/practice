export class RetrieveMedia
{
    userId:number;
    url:string;
    title:string;
    description:string;
    tags:string;
    type:string;
}