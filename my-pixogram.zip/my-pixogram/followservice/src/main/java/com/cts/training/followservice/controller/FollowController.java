package com.cts.training.followservice.controller;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.followservice.entity.Follow;
import com.cts.training.followservice.repository.FollowRepository;


@RestController
public class FollowController {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	
	

	// dependency
	@Autowired
	private FollowRepository followRepository;
	@GetMapping("/check-followings/mine/{mineId}/other/{otherId}")
	public ResponseEntity<Boolean> getFollowingStatus(@PathVariable Integer mineId, @PathVariable Integer otherId){
		
		Boolean status = this.followRepository.checkFollowing(mineId, otherId);
		ResponseEntity<Boolean> result = new ResponseEntity<Boolean>(status,HttpStatus.OK);
		return result;
		
	}
	
	// REST method that will recieve a movie Id and return details of that movie
	// ENDPOINT : /movies/{movieId}
	/*@GetMapping("/follows/{followerId}")
	public ResponseEntity<Follow> followDetail(@PathVariable Integer followerId){
		Optional<Follow> record =  this.followRepository.findById(followerId);
	Follow follow = new Follow();
		if(record.isPresent())
			follow = record.get();
		ResponseEntity<Follow> response = new ResponseEntity<Follow>(follow, HttpStatus.OK);
		return response;
	}*/
}












